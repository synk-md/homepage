## One guide, three routes
Enough variety for a weekend. Small enough to finish well.

## Print comes first
The layout has to work folded in a coat pocket.

## No ratings
Describe what makes a place worth stopping for. Let the reader decide.
