## What moved forward
- Maya walked the harbor route.
- Alex drafted the opening essay.
- Sam tested the print size.

## Decisions
Keep the first guide to three routes. Put practical details beside the directions.

## Before we meet again
- [ ] Maya: check the footbridge alternative
- [ ] Alex: shorten the introduction
- [ ] Sam: print a folded test copy
