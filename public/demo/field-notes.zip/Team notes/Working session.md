## Today’s goal
Finish the harbor route together.

## Agenda
1. Read the directions from start to finish.
2. Mark anything a new reader might miss.
3. Agree on the coffee stop.
4. Choose one thing to remove.

## Notes from the room
Leave space here for everyone’s observations.
