| Observation | Change to try |
| --- | --- |
| The start was hard to find | Add a visible landmark |
| The map felt too small | Remove secondary labels |
| The café detail was helpful | Add one practical detail per stop |

## Next review
Watch someone use the guide without explaining it to them.
