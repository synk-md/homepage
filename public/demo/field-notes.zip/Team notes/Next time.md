## Do again
Walk the route before writing about it. Bring someone who asks different questions.

## Change
Start print tests earlier. Keep a list of assumptions while writing.

## Remember
A finished small guide is more useful than a perfect plan for a big one.
