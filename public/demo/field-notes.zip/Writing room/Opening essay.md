# Take the long way home
There is a version of the city you only meet on foot.

It lives in the ten minutes between the station and the café, in the street you usually pass without turning, in the sound of a workshop behind an open door.

This guide is an invitation to leave a little room in the afternoon.

## A note for the next draft
Less explaining. More things you can see, hear, and smell.
