## Three possibilities
1. Leave the main road at the blue door.
2. The shortest way there is not the best way there.
3. This is a walk for a day with no particular plans.

## Our pick
The blue door. It gives the reader somewhere to go.
