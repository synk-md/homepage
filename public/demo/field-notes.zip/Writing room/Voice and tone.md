## Sound like a friend who knows the area
Use short directions and details you noticed yourself.

## Prefer
“Turn left at the bookshop. Stop if the door is open.”

## Skip
“Discover an unforgettable urban experience.”

## Read it aloud
If a sentence sounds like an advertisement, write it again.
