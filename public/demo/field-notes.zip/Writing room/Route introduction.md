# By the water
Start early if you can. The first stretch follows the harbor while the city is still deciding what kind of day to have.

You’ll pass old warehouses, a small square, and a café with a very good window seat.

**Allow about an hour, plus whatever time you spend looking at the boats.**
