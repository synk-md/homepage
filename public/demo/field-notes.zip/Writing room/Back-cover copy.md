# A little room for a detour
Three neighborhood walks. A few favorite stops. No need to hurry.

Bring comfortable shoes, a curious friend, and an afternoon you haven’t filled yet.

**Field Notes — a small guide to looking closer.**
