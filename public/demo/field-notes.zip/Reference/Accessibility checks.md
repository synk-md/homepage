These are questions for our fictional route test, not verified accessibility claims.

- [ ] Identify steps and steep sections
- [ ] Check path widths at narrow points
- [ ] Note places to sit
- [ ] Find a step-free alternative
- [ ] Describe the surface after rain

Publish what we observed and what we still need to check.
