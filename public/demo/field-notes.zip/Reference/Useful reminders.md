Save a copy before a big revision.

A recommendation is stronger when it says why.

Never use a temporary sign as the only landmark.

Check the route in both directions.

Leave the reader room to make the afternoon their own.
