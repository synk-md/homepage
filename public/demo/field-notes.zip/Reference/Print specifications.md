## Working format
One folded sheet. Large enough type to read outdoors. High contrast for a cloudy day.

## Test before committing
Print at actual size. Fold it, put it in a pocket, and use it on a walk.

## Files to keep
- Editable source
- Print-ready export
- A dated copy of the final text
