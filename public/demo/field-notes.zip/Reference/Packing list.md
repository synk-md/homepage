## For a route test
- [x] Printed draft
- [x] Pencil
- [ ] Water bottle
- [ ] Weather-appropriate layer
- [ ] Fully charged phone

## Nice to have
A small camera and a friend who notices things you don’t.
