Fictional interview notes.

## Reader A
“I want one good route, not fifty options.”

## Reader B
“If it rains, I still want a reason to go out.”

## What we heard
Make the decisions easy. Give people an obvious starting point, a place to stop, and permission to take a detour.
