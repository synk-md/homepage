Fictional locations for planning the demo guide.

| Place | Why stop | Best detail |
| --- | --- | --- |
| The Blue Cup | Mid-walk pause | Window seats |
| Common Ground | Room for a group | Big shared table |
| Little Hours | Quiet finish | Books by the door |

## Still to learn
Which places have space for a wheelchair and a wet coat?
