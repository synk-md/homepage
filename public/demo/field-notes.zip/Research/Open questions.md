- Does a route need an endpoint, or is a loop easier?
- How much history belongs in a walking guide?
- Can the shortest route work in half an hour?
- Where do we send someone who wants to keep walking?

## How we’ll answer them
Try the draft with two people who have never seen the neighborhood.
