The side streets were the highlight. Fewer signs, more open windows, and a bakery we nearly missed.

## Keep
- The courtyard with the climbing plants
- The corner where you can hear the workshop
- The bench facing the evening sun

## Avoid
Directions that rely on parked cars or temporary signs.
