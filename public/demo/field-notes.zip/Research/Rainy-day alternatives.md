## Keep the walk short
Swap the exposed harbor stretch for the covered market arcade.

## Give every route a warm stop
A bookshop, café, or small gallery makes a wet afternoon feel intentional.

## Pack list
- [ ] Light waterproof layer
- [ ] A folded paper guide
- [ ] A little patience
