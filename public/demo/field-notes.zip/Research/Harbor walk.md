## First impressions
Best before the streets get busy. The water catches the light along the old warehouse wall.

## Route notes
1. Start at the clock by the ferry steps.
2. Follow the water until the path turns inland.
3. Take the narrow lane past the blue door.
4. Finish at the small square with the long bench.

## To check
- [ ] Find a step-free alternative to the footbridge
- [ ] Time the walk with a coffee stop
- [ ] Check shelter along the route
