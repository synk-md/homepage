| Stage | Owner | Ready when |
| --- | --- | --- |
| Explore | Maya | All three routes walked |
| Write | Alex | First drafts reviewed |
| Test | Sam | Two readers try each route |
| Share | Everyone | The guide fits in a pocket |

## This week’s focus
Finish one route all the way through before adding another.
