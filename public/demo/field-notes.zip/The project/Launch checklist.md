## Content
- [x] Name the guide
- [x] Write the project brief
- [ ] Read every direction out loud
- [ ] Check opening hours with each venue
- [ ] Add accessible alternatives

## Final checks
- [ ] Print a copy in black and white
- [ ] Walk the route using only the printed guide
- [ ] Export a backup of the notebook
