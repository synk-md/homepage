## Who this is for
Someone with a free Saturday and no desire to spend it making a spreadsheet.

## What we’re making
A short, printable neighborhood guide with three routes and a handful of personal recommendations.

## What success looks like
- The route works without looking at a phone every two minutes.
- Each stop has a reason to be here.
- The guide leaves room for detours.

## What can wait
Booking integrations, ratings, accounts, and a second city.
