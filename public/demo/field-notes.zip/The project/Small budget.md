These are fictional planning figures, not vendor quotes.

| Item | Allowance |
| --- | --- |
| Test prints | 40 |
| Coffee for testers | 60 |
| First print run | 180 |
| Spare | 20 |

**Total: 300 budget units.** Keep the first edition small enough to change our minds.
