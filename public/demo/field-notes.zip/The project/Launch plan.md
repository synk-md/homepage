# A weekend worth sharing
A pocket-sized guide to taking the long way home.

## The idea
Three walks, six good stops, and enough space to get a little lost. Made by people who would rather explore than scroll.

## Before we share it
- [x] Pick our first neighborhood
- [x] Walk the route once in the rain
- [ ] Add a café stop to the harbor walk
- [ ] Ask someone new to try the directions

## Working notes
The best discoveries happen between the places you planned to visit.

## Next up
