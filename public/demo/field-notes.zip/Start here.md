# Field Notes
A small team. A good idea. A notebook to work it out.

We’re putting together a weekend field guide for curious people: quiet walks, independent cafés, and places worth stopping for.

## Around the notebook
- **The project** — what we’re making and what happens next.
- **Research** — observations, interviews, and questions.
- **Writing room** — rough drafts with room for another voice.
- **Team notes** — decisions, agendas, and things to follow up.
- **Reference** — the details we always need to look up.

## This week
- [x] Choose the first neighborhood
- [x] Collect the team’s favorite places
- [ ] Finish the walking route
- [ ] Review the opening essay together

> Everything in this notebook is fictional demo content. Make a copy, edit a paragraph, and try it with a friend.
